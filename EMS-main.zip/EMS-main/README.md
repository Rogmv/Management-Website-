# EMS
EMS is an employee management system that facilitates HR managers to keep up-to-date records of employees, manage information and communicate with employees through a single portal.
 

Through EMS, HR managers can search employee records using hundreds of parameters, generate analytic reports and automate salary incrementation and notification tasks with the help of a few clicks.
EMS also allows the managers to upload Excel records of employee details to add new employees while providing options to add and update employees individually. In addition, employee information is
displayed through a unique show page for each employee, which shows all relevant information about the employee in the database, including their salary history.

With a simplistic and user-friendly interface, EMS helps to improve organizations&#39; productivity by automating monotone and repetitive tasks, and allowing HR managers to invest their time and effort on the development and satisfaction of the employees.
