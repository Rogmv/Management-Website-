import ShowEmployee from "../components/ShowEmployee";

const ShowPage = (props) => {
    return <ShowEmployee results={props.results}/>
}

export default ShowPage;